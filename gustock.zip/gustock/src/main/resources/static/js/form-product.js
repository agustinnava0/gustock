$(document).ready(()=>{

    // Validacion de código
    $('#codigo').on('keyup', function() {
        var codigo = $(this).val();
        $.ajax({
            url: '/gustock/validarCodigo',
            type: 'GET',
            data: {codigo: codigo},
            success: function(response) {
                if (response.error) {
                    // Muestra mensaje de error
                    $("#codigoError").text(response.error);
                    $("#codigo").css("border", "1px solid red");
                } else {
                    // Limpia el mensaje
                    $("#codigoError").text("");
                    $("#codigo").css("border", "none");
                }
            }
        });
    });

    // Customizacion de precios
    $('#precioDebito, #precioEfectivo, #precioTarjeta').on('keyup click change paste input', function (event) {
        $(this).val(function (index, value) {
            if (value != "") {
                var decimalCount;
                value.match(/\,/g) === null ? decimalCount = 0 : decimalCount = value.match(/\,/g);

                if (decimalCount.length > 1) {
                    value = value.slice(0, -1);
                }

                var components = value.toString().split(",");
                if (components.length === 1)
                    components[0] = value;
                components[0] = components[0].replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                if (components.length === 2) {
                    components[1] = components[1].replace(/\D/g, '').replace(/^\d{3}$/, '');
                }

                if (components.join(',') != '')
                    return '$ ' + components.join(',');
                else
                    return '';
            }
        });
    });

    formatPrice(); // call the function when the page loads

    // Muestra imagen seleccionada en el momento
    $('#imagen').change(function(){
        const file = this.files[0];
        console.log(file);
        if (file){
            let reader = new FileReader();
            reader.onload = function(event){
                console.log(event.target.result);
                $('#imgPreview').attr('src', event.target.result);
            }
            reader.readAsDataURL(file);
        }
    });

    // Generador de codigo aleatorio
    $('#generate-code').click(function() {
        var randomNumber = Math.floor(Math.random() * 90000000) + 10000000; // Generate a random number
        $('#codigo').val(randomNumber); // Set the value of the input to the generated random number
    });

    // Generador de codigo de barras aleatorio
    $('#generate-barcode').click(function() {
        $('#image2').remove();
        $('#barcode-svg').css("display", "inline");

        var randomBarcode =  Math.floor(Math.random() * 1000000000000); // generate random EAN-13 barcode
        JsBarcode("#barcode-svg", randomBarcode, {format: "ean13"}); // generate barcode using jsbarcode library
        generateBarcode();

        var svgTextElements = $('svg text');

        var concatenatedText = "";
        svgTextElements.each(function() {
            var textContent = $(this).text();
            if (textContent.length > 0) {
                concatenatedText += textContent;
            }
        });

        $("#barcode").val(parseInt(concatenatedText));
    });

    // Lector codigo de barras
    document.addEventListener('keydown', (ev) => {
        if ($("#barcode").val().length != 13) {
            if (ev.ctrlKey || ev.altKey) return;

            if (ev.key == 'Enter') {
            } else if (ev.key == 'Space') {
                document.getElementById('barcode').value += ' ';
            } else if (ev.key.length == 1) {
                document.getElementById('barcode').value += ev.key;
            }

            if ($("#barcode").val().length == 13) {
                JsBarcode("#barcode-svg", $("#barcode").val(), {format: "ean13"});
                generateBarcode();
            }
        }
    });

    // Genera un PNG del barcode
    function generateBarcode() {
        // Load the SVG image in the canvas
        var canvas = document.createElement('canvas');
        var svgElement = document.getElementById('barcode-svg');
        canvas.width = svgElement.clientWidth;
        canvas.height = svgElement.clientHeight;
        var context = canvas.getContext('2d');
        var svgString = new XMLSerializer().serializeToString(svgElement);
        var svgImage = new Image();
        svgImage.src = 'data:image/svg+xml;base64,' + btoa(svgString);
        svgImage.onload = function () {
            context.drawImage(svgImage, 0, 0);

            // Convert canvas to PNG and set hidden input value
            var png = canvas.toDataURL("image/png");
            var base64Image = png.split(",")[1];
            $("#barcode-image").val("data:image/png;base64," + base64Image);
        };
    }

    // Borra el codigo de barras generado o escaneado
    $('#delete-barcode').click(function() {
        $("#barcode-container svg").text("");
        $("#barcode-image").val("");
        $("#barcode").val("");

        // Vista modificar producto
        $("#image2").css("display", "none");
        $("#barcode-container svg").css("display", "block");
    });

    // Completa el campo de precio debito automaticamente
    $('#precioEfectivo').on('keyup', function() {
        var value = $(this).val();
        $('#precioDebito').val(value);
    });

    // Convierte los valores de los input de precio en float y a los inputs en tipo number
    $("form").submit(function() {

        var precioEfectivo = parseFloat($("#precioEfectivo").val().replace(/[^0-9-]+/g, ''));
        var precioDebito = parseFloat($("#precioDebito").val().replace(/[^0-9-]+/g, ''));
        var precioTarjeta = parseFloat($("#precioTarjeta").val().replace(/[^0-9-]+/g, ''));

        $("#precioEfectivo, #precioDebito, #precioTarjeta").attr("type", "number");

        $("#precioEfectivo").val(precioEfectivo);
        $("#precioDebito").val(precioDebito);
        $("#precioTarjeta").val(precioTarjeta);

        return true;
    });

});

function formatPrice() {
    $('#precioDebito, #precioEfectivo, #precioTarjeta').each(function() {
        var value = $(this).val();
        if (value != "") {
            var decimalCount;
            value.match(/\,/g) === null ? decimalCount = 0 : decimalCount = value.match(/\,/g);

            if (decimalCount.length > 1) {
                value = value.slice(0, -1);
            }

            var components = value.toString().split(",");
            if (components.length === 1)
                components[0] = components[0].slice(0, -1).replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            if (components.length === 2) {
                components[1] = components[1].replace(/\D/g, '').replace(/^\d{3}$/, '');
            }

            if (components.join(',') != '')
                $(this).val('$ ' + components.join(','));
        }
    });
}
