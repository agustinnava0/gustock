var finalSubtotal = 0;

$(document).ready(function() {
    $("#search-product").submit(function(e) {
        e.preventDefault();

        var codigo = $('#codigo').val();
        var tipoPrecio = $('#tipoPrecio').val();

        $.ajax({
            url: '/gustock/venta/producto/' + codigo + '?tipoPrecio=' + tipoPrecio,
            method: 'GET',
            success: function(response) {
                // if the product exists is added to the table
                if (response.codigo) {
                    var newRow =
                        '<tr id="' + response.codigo + '" class="text-center align-middle">' +
                            '<td>' + response.codigo + '</td>' +
                            '<td>' + response.descripcion + '</td>' +
                            // Price
                            '<td><span class="me-3">' + response.tipo + '</span>' +
                            '       <input class="text-center border" id="precio-'+ response.codigo + '" type="text"' +
                            '       onkeyup="subtotalProduct(this)"' +
                            '       value="' + response.precio.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }) + '"></td>' +
                            // Quantity
                            '<td class="text-center"><input class="w-75 text-center border" id="cantidad-'+ response.codigo + '" type="number" min="1" value="1"' +
                            '       onkeyup="subtotalProduct(this)" onchange="subtotalProduct(this)"></td>' +
                            // Subtotal as result of price and quantity
                            '<td><input class="text-center bg-transparent border-0"  id="subtotal-'+ response.codigo + '" type="text" disabled' +
                            '       onchange="subtotalProduct(this)"' +
                            '       value="' + response.precio.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }) + '"></td>' +
                            '<td>' +
                            '<a type="button" class="text-danger mx-3 my-1"\n' +
                            '   title="Eliminar producto"\n' +
                            '   onclick="deleteRow(' + response.codigo + ')">' +
                            '   <i class="bi bi-trash3-fill" width="16" height="16"></i>' +
                            '</a>' +
                            '</td>'+
                        '</tr>';
                    $('table tbody').append(newRow);
                }

                calculateSubtotal();
                calculateTotal();
            },
            error: function() {
                alert('Producto no encontrado');
            }
        });
    });

    // Lector codigo de barras
    $("#codigo").on((ev) => {
        if ($("#codigo").val().length != 13) {
            if (ev.ctrlKey || ev.altKey) return;
            if (ev.key == 'Enter') {
                ev.preventDefault(); // prevent form submission
            } else if (ev.key == 'Space') {
                document.getElementById('codigo').value += ' ';
            } else if (ev.key.length == 1) {
                document.getElementById('codigo').value += ev.key;
            }
        }
    });

    // Customizacion de precios
    $('#pagoEfectivo, #pagoDebito, #pagoCredito').on('keyup change paste input', function (event) {
        $(this).val(function (index, value) {
            if (value != "") {
                var decimalCount;
                value.match(/\,/g) === null ? decimalCount = 0 : decimalCount = value.match(/\,/g);

                if (decimalCount.length > 1) {
                    value = value.slice(0, -1);
                }

                var components = value.toString().split(",");
                if (components.length === 1)
                    components[0] = value;
                components[0] = components[0].replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                if (components.length === 2) {
                    components[1] = components[1].replace(/\D/g, '').replace(/^\d{3}$/, '');
                }

                if (components.join(',') != '')
                    return '$ ' + components.join(',');
                else
                    return '';
            }
        });

        sumAndDisplay();
    });
});

// Function to delete a row
function deleteRow(codigo) {
    if (confirm("¿Está seguro de que desea eliminar el producto de la venta?")) {
        // Get the product's subtotal
        var subtotalStr = $("#subtotal-" +codigo).val();
        var subtotal = parseFloat(subtotalStr.replace(/[^0-9,]/g, '').replace('.', '').replace(',', '.'));

        finalSubtotal -= subtotal;
        $("#" + codigo).remove();

        // Update the final subtotal and total after delete the row
        calculateSubtotal();
        calculateTotal();
    }
}

// Function to calculate the subtotal for a product
function subtotalProduct(element) {
    // Get the product's price and quantity
    var precio = parseFloat($(element).closest('tr').find('[id^="precio-"]').val().replace(/[^0-9,]/g, '').replace('.', '').replace(',', '.'));
    var cantidad = parseInt($(element).closest('tr').find('[id^="cantidad-"]').val());

    if(isNaN(precio)){
        precio = 0;
    }

    if (isNaN(cantidad)) {
        cantidad = 0;
    }
    // Calculate the subtotal
    var subtotal = precio * cantidad;

    // Update the subtotal cell for the product
    $(element).closest('tr').find('[id^="subtotal-"]').val(subtotal.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }));

    // Update the final subtotal
    calculateSubtotal();
    calculateTotal();
}

// Function to update the final subtotal
function calculateSubtotal() {
    // Get the subtotal for each product and add them together
    var subtotals = 0;
    $('[id^="subtotal-"]').each(function() {
        subtotals += parseFloat($(this).val().replace(/[^0-9,]/g, '').replace('.', '').replace(',', '.'));
    });

    // Update the final subtotal and display it
    finalSubtotal = subtotals;
    $('#subtotal').text(finalSubtotal.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }));
}

function calculateTotal() {
    applyDiscount($("#descuentoPorcentaje"));
    var descuentoStr = $('#descuento').text().replace(/[^0-9,]/g, '').replace('.', '').replace(',', '.');

    var descuento = parseFloat(descuentoStr);
    var total = finalSubtotal - descuento;
    $('#total').text(total.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }));
    $('#totalPagar').val(total.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }));
}

function applyDiscount(percentage) {
    var discountPercentage = $(percentage).val();

    // Check if the input value is a valid number
    if (isNaN(discountPercentage)) {
        discountPercentage = 0;
    }

    var discountAmount = finalSubtotal * (discountPercentage / 100);

    if (discountAmount != NaN){
        $('#descuento').text(discountAmount.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }));
    } else {
        $('#descuento').text("$ 0,00");
    }
}

function sumAndDisplay() {
    var efectivoVal = parseFloat($('#pagoEfectivo').val().replace(/\./g, '').replace(',', '.').replace('$ ', ''));
    var debitoVal = parseFloat($('#pagoDebito').val().replace(/\./g, '').replace(',', '.').replace('$ ', ''));
    var creditoVal = parseFloat($('#pagoCredito').val().replace(/\./g, '').replace(',', '.').replace('$ ', ''));

    if (isNaN(efectivoVal)){
        efectivoVal = 0;
    }
    if (isNaN(debitoVal)){
        debitoVal = 0;
    }
    if (isNaN(creditoVal)){
        creditoVal = 0;
    }

    var totalPagar = efectivoVal + debitoVal + creditoVal;
    var formattedTotal = '$ ' + totalPagar.toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    $('#totalPagado').val(formattedTotal);
}


