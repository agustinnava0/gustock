$(document).ready(function() {
    $('#download').click(function() {
        var imgSrc = $('#barcode').attr('src');
        var link = document.createElement('a');
        link.href = imgSrc;

        // Extract the image name from the imgSrc URL using split() and pop() methods
        var imageName = imgSrc.split('/').pop();

        link.download = imageName; // Set the download attribute value to the image name
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
});