$(document).ready(()=>{
    $("#codeSearch").on((ev) => {
        // Check if the input value has length 13
        if ($("#codeSearch").val().length !== 13) {

            // Check if ctrl or alt key is pressed
            if (ev.ctrlKey || ev.altKey) return;

            // Handle key presses
            if (ev.key == 'Enter') {
                // Handle Enter key press
            } else if (ev.key.length == 1) {
                // Handle other key presses
                document.getElementById('codeSearch').value += ev.key;
            }
        }
    });
});