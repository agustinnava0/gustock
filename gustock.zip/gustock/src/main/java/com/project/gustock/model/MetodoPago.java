package com.project.gustock.model;

public enum MetodoPago {

    CONTADO, TARJETA, OTRO
}
