package com.project.gustock.service;

import com.project.gustock.model.Local;
import com.project.gustock.model.TipoLocal;

import java.util.List;

public interface LocalService {

    void save(Local local);
    void delete(Local local);
    List<Local> findAll();
    List<Local> findAllByTipo(TipoLocal tipo);
    Local getById(Long id);

}
