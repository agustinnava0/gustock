package com.project.gustock.service;

import com.project.gustock.model.Rubro;

import java.util.List;
import java.util.Optional;

public interface RubroService {

    void save(Rubro rubro);
    void delete(Rubro rubro);
    List<Rubro> findAll();
    Rubro getById(Long id);
}
