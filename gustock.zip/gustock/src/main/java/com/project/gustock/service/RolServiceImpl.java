package com.project.gustock.service;

import com.project.gustock.model.Rol;
import com.project.gustock.repository.RolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RolServiceImpl implements RolService {

    @Autowired
    RolRepository rolRepository;

    @Override
    public List<Rol> findAll(){return rolRepository.findAll();}

    @Override
    public Rol getRolByName(String name){return rolRepository.findRolByName(name);}
}
