package com.project.gustock.service;

import com.project.gustock.model.Marca;

import java.util.List;
import java.util.Optional;

public interface MarcaService {

    void save(Marca marca);
    void delete(Marca marca);
    List<Marca> findAll();
    Marca getById(Long id);

}
