package com.project.gustock.repository;

import com.project.gustock.model.Rubro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RubroRepository extends JpaRepository<Rubro, Long> {

}
