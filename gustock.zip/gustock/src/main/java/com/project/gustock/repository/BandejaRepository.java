package com.project.gustock.repository;

import com.project.gustock.model.Bandeja;
import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BandejaRepository extends JpaRepository<Bandeja, Long> {

    List<Bandeja> findAllByUsuarioAndLeidoIsNull(Usuario usuario);

    List<Bandeja> findAllByUsuarioAndLeidoIsNotNull(Usuario usuario);

    List<Bandeja> findAllByNotificacion(Notificacion notificacion);

}
