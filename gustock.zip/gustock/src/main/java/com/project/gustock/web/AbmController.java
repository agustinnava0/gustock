package com.project.gustock.web;

import com.project.gustock.model.*;
import com.project.gustock.repository.RubroRepository;
import com.project.gustock.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AbmController {

    @Autowired
    private LocalService localService;
    @Autowired
    private ProveedorService proveedorService;
    @Autowired
    private UsuarioService usuarioService;
    @Autowired
    private RubroService rubroService;
    @Autowired
    private MarcaService marcaService;

    @PostMapping("/administrador/panel/local/registrar")
    public String registrarLocal(@ModelAttribute("nuevoLocal") Local local) {
        localService.save(local);
        String mensaje = "La SUCURSAL fue agregada con exito!";
        return "redirect:/administrador/panel?exito=" + mensaje;
    }

    @GetMapping("/administrador/panel/local/eliminar/{id}")
    public String eliminarLocal(@PathVariable("id") Long id) {
        Local local = localService.getById(id);
        localService.delete(local);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/local/actualizar")
    public String actualizarLocal(@ModelAttribute("local") Local local) {
        localService.save(local);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/proveedor/registrar")
    public String registrarProveedor(@ModelAttribute("nuevoProveedor") Proveedor proveedor) {
        proveedorService.save(proveedor);
        String mensaje = "El PROVEEDOR fue agregado con exito!";
        return "redirect:/administrador/panel?exito=" + mensaje;
    }

    @GetMapping("/administrador/panel/proveedor/eliminar/{id}")
    public String eliminarProveedor(@PathVariable("id") Long id) {
        Proveedor proveedor = proveedorService.getById(id);
        proveedorService.delete(proveedor);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/proveedor/actualizar")
    public String actualizarProveedor(@ModelAttribute("proveedor") Proveedor proveedor) {
        proveedorService.save(proveedor);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/usuario/registrar")
    public String registrarUsuario(@ModelAttribute("nuevoUsuario") Usuario usuario) {
        usuarioService.save(usuario);
        String mensaje = "El USUARIO fue agregado con exito!";
        return "redirect:/administrador/panel?exito=" + mensaje;
    }

    @GetMapping("/administrador/panel/usuario/eliminar/{id}")
    public String elminarUsuario(@PathVariable("id") Long id) {
        Usuario usuario = usuarioService.findUsuarioById(id);
        usuarioService.delete(usuario);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/usuario/actualizar")
    public String actualizarUsuario(@ModelAttribute("usuario") Usuario usuario) {
        usuarioService.save(usuario);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/rubro/registrar")
    public String registrarRubro(@ModelAttribute("nuevoRubro") Rubro rubro) {
        rubroService.save(rubro);
        String mensaje = "El RUBRO fue agregado con exito!";
        return "redirect:/administrador/panel?exito=" + mensaje;
    }

    @GetMapping("/administrador/panel/rubro/eliminar/{id}")
    public String eliminarRubro(@PathVariable("id") Long id) {
        Rubro rubro = rubroService.getById(id);
        rubroService.delete(rubro);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/rubro/actualizar")
    public String actualizarRubro(@ModelAttribute("rubro") Rubro rubro) {
        rubroService.save(rubro);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/marca/registrar")
    public String registrarMarca(@ModelAttribute("nuevaMarca") Marca marca) {
        marcaService.save(marca);
        String mensaje = "La MARCA fue agregada con exito!";
        return "redirect:/administrador/panel?exito=" + mensaje;
    }

    @GetMapping("/administrador/panel/marca/eliminar/{id}")
    public String eliminarMarca(@PathVariable("id") Long id) {
        Marca marca = marcaService.getById(id);
        marcaService.delete(marca);
        return "redirect:/administrador/panel";
    }

    @PostMapping("/administrador/panel/marca/actualizar")
    public String actualizarMarca(@ModelAttribute("marca") Marca marca) {
        marcaService.save(marca);
        return "redirect:/administrador/panel";
    }
}

