package com.project.gustock.service;

import com.project.gustock.model.Bandeja;
import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Usuario;
import com.project.gustock.repository.BandejaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BandejaServiceImpl implements BandejaService{

    @Autowired
    BandejaRepository bandejaRepository;

    @Override
    public void save(Bandeja bandeja) {bandejaRepository.save(bandeja);}

    @Override
    public Bandeja getById(Long id) {return bandejaRepository.getReferenceById(id);}

    @Override
    public List<Bandeja> findAllByUsuarioAndLeidoIsNull(Usuario usuario) {return bandejaRepository.findAllByUsuarioAndLeidoIsNull(usuario);}

    @Override
    public List<Bandeja> findAllByUsuarioAndLeidoIsNotNull(Usuario usuario) {return bandejaRepository.findAllByUsuarioAndLeidoIsNotNull(usuario);}

    @Override
    public List<Bandeja> findAllByNotificacion(Notificacion notificacion) {return bandejaRepository.findAllByNotificacion(notificacion);}

    @Override
    public void delete(Bandeja bandeja) {bandejaRepository.delete(bandeja);}

}
