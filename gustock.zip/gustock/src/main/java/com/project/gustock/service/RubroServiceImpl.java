package com.project.gustock.service;

import com.project.gustock.model.Rubro;
import com.project.gustock.repository.RubroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RubroServiceImpl implements RubroService{

    @Autowired
    RubroRepository rubroRepository;

    @Override
    public void save(Rubro rubro){rubroRepository.save(rubro);}

    @Override
    public void delete(Rubro rubro){rubroRepository.delete(rubro);}

    @Override
    public List<Rubro> findAll(){return rubroRepository.findAll();}

    @Override
    public Rubro getById(Long id){return rubroRepository.getReferenceById(id);}
}
