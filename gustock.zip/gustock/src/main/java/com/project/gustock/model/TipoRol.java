package com.project.gustock.model;

public enum TipoRol {

    ROLE_ADMINISTRADOR, ROLE_USUARIO
}
