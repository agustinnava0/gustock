package com.project.gustock.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Entity
@Getter
@Setter
public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long nroVenta;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    private LocalDate fecha;

    private LocalTime hora;

    private Long clienteContacto;

    @Enumerated(EnumType.STRING)
    private MetodoPago metodoPago;

    private Integer descuento;

    private Double importe;
    private Double contado;
    private Double tarjeta;

    @OneToMany
    private List<Detalle> detalle;

    @ManyToOne
    private Usuario usuario;

    private String nota;


}
