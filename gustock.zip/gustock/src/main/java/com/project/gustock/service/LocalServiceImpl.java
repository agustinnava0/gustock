package com.project.gustock.service;

import com.project.gustock.model.Local;
import com.project.gustock.model.TipoLocal;
import com.project.gustock.repository.LocalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LocalServiceImpl implements LocalService{

    @Autowired
    LocalRepository localRepository;

    @Override
    public void save(Local local){localRepository.save(local);}

    @Override
    public void delete(Local local){localRepository.delete(local);}

    @Override
    public List<Local> findAll(){return localRepository.findAll();}

    @Override
    public List<Local> findAllByTipo(TipoLocal tipo){return localRepository.findAllByTipo(tipo);}

    @Override
    public Local getById(Long id){return localRepository.getById(id);}
}
