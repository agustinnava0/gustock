package com.project.gustock.service;

import com.project.gustock.model.Bandeja;
import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Usuario;

import java.util.List;

public interface BandejaService {

    void save(Bandeja bandeja);

    Bandeja getById(Long id);

    List<Bandeja> findAllByUsuarioAndLeidoIsNull(Usuario usuario);

    List<Bandeja> findAllByUsuarioAndLeidoIsNotNull(Usuario usuario);

    List<Bandeja> findAllByNotificacion(Notificacion notificacion);

    void delete(Bandeja bandeja);

}
