package com.project.gustock.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String Remitente;
    private String asunto;

    @Column(columnDefinition="LONGTEXT")
    private String mensaje;

    @DateTimeFormat(pattern="yyyy-MM-dd'T'HH:mm")
    private LocalDateTime fechaHora;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Bandeja> destinatarios;

}
