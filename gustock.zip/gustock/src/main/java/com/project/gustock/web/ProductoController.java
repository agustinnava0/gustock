package com.project.gustock.web;

import com.project.gustock.exceptions.ExceptionCodigoRepetido;
import com.project.gustock.exceptions.ExceptionProductoNoEncontrado;
import com.project.gustock.model.*;
import com.project.gustock.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Controller
public class ProductoController {

    @Autowired
    private ProductoService productoService;
    @Autowired
    private FileService fileService;
    @Autowired
    private BarcodeService barcodeService;
    @Autowired
    private ImagenService imagenService;
    @Autowired
    private StockService stockService;
    @Autowired
    private LocalService localService;
    @Autowired
    private ProveedorService proveedorService;
    @Autowired
    private RubroService rubroService;
    @Autowired
    private MarcaService marcaService;

    @GetMapping("/producto/{codigo}")
    public String verProducto(@PathVariable("codigo") String codigo, Model model) {
        Producto producto;
        try {
            producto = productoService.findByCodigo(codigo);
        } catch (ExceptionProductoNoEncontrado e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("producto", new Producto());
            model.addAttribute("stocks", new ArrayList<Stock>());
            return "ver-producto";
        }

        List<Stock> stocks = stockService.findAllByProducto(producto);

        model.addAttribute("producto", producto);
        model.addAttribute("stocks", stocks);
        return "ver-producto";
    }

    @GetMapping("/validarCodigo")
    @ResponseBody
    public Map<String, Object> validarCodigo(@RequestParam("codigo") String codigo) throws ExceptionProductoNoEncontrado {
        Map<String, Object> response = new HashMap<>();
        try{
            if (productoService.findByCodigo(codigo) != null) {
                response.put("error", "Ya existe un producto con este código");
            }
        } catch (ExceptionProductoNoEncontrado e) {
            response.put("e", e);
        }
        return response;
    }

    @GetMapping("/administrador/panel/productos/registrar")
    public String irRegistrarProducto(@RequestParam(value = "producto", required = false) Long producto, @RequestParam(value = "error", required = false) String error, Model model){
        Producto nuevoProducto;
        if (producto != null){
            nuevoProducto = productoService.getById(producto);
        } else {
            nuevoProducto = new Producto();
        }
        List<Local> sucursales = localService.findAll();

        //Selects
        List<Proveedor> proveedores = proveedorService.findAll();
        List<Rubro> rubros = rubroService.findAll();
        List<Marca> marcas = marcaService.findAll();
        //Fin selects

        if(error != null){
            model.addAttribute("error", error);
        }

        model.addAttribute("nuevoProducto", nuevoProducto);
        model.addAttribute("listaSucursales", sucursales);
        model.addAttribute("proveedores", proveedores);
        model.addAttribute("rubros", rubros);
        model.addAttribute("marcas", marcas);
        return "registrar-producto";
    }

    @PostMapping("/administrador/producto/registrar")
    public String registrarProducto(@ModelAttribute("nuevoProducto") Producto product,
                                    @RequestParam(value = "image", required = false) MultipartFile image,
                                    @RequestParam(value = "barcode", required = false) Long barcode,
                                    @RequestParam(value = "barcodeImage", required = false) String barcodeImage,
                                    @RequestParam Map<String, String> storeQuantities, Model model) throws Exception {
        Producto producto;

        // Asignacion de precios
        Double precioEfectivo = product.getPrecioEfectivo() != null ? product.getPrecioEfectivo() : 0.0;
        product.setPrecioEfectivo(precioEfectivo);
        Double precioDebito = product.getPrecioDebito() != null ? product.getPrecioDebito() : 0.0;
        product.setPrecioDebito(precioDebito);
        Double precioCredito = product.getPrecioCredito() != null ? product.getPrecioCredito() : 0.0;
        product.setPrecioCredito(precioCredito);

        if (precioEfectivo != 0.0 || precioDebito != 0.0 || precioCredito != 0.0) {
            product.setUltActPrecio(LocalDateTime.now());
        }
        // Fin de asignacion

        if (image.getOriginalFilename() != "") {
            fileService.storeImage(image, image.getOriginalFilename());
            Imagen imagen = imagenService.save(new Imagen(image.getOriginalFilename()));
            product.setImagen(imagen);
        }

        if (barcodeImage != null && !barcodeImage.isEmpty()) {
            String barcodeName = barcode + ".png";
            byte[] barcodeData = Base64.getDecoder().decode(barcodeImage.split(",")[1]);
            fileService.storeBarcode(barcodeData, barcodeName);
            Barcode barcodeEntity = barcodeService.save(new Barcode(barcodeName, barcode));
            product.setBarcode(barcodeEntity);
        }

        try {
            producto = productoService.save(product);
        } catch (ExceptionCodigoRepetido e){
            return "redirect:/administrador/panel/productos/registrar?error=" + e.getMessage();
        }

        // Distribucion del Stock
        List<Local> sucursales = localService.findAll();
        for (Local sucursal : sucursales) {
            if(!storeQuantities.get(sucursal.getId().toString()).isEmpty()){
                int quantity = Integer.parseInt(storeQuantities.get(sucursal.getId().toString()));
                if (quantity >= 0){
                    Stock stock = new Stock(producto, sucursal, quantity, LocalDateTime.now());
                    stockService.save(stock);
                }
            }
        }

        return "redirect:/administrador/panel/productos";
    }

    @GetMapping("/administrador/producto/{codigo}/modificar")
    public String irEditarProducto(@PathVariable("codigo") String codigo, Model model) throws ExceptionProductoNoEncontrado {
        Producto producto = productoService.findByCodigo(codigo);

        List<Local> sucursales = localService.findAll();
        List<Stock> listadoStock = stockService.findAllByProducto(producto);

        for (Stock stock: listadoStock){
            if(sucursales.contains(stock.getLocal())){
                sucursales.remove(stock.getLocal());
            }
        }

        //Selects
        List<Proveedor> proveedores = proveedorService.findAll();
        List<Rubro> rubros = rubroService.findAll();
        List<Marca> marcas = marcaService.findAll();
        //Fin selects

        model.addAttribute("proveedores", proveedores);
        model.addAttribute("rubros", rubros);
        model.addAttribute("marcas", marcas);
        model.addAttribute("producto", producto);
        model.addAttribute("sucursales", sucursales);
        model.addAttribute("listadoStock", listadoStock);
        return "modificar-producto";
    }

    @PostMapping("/administrador/producto/modificar")
    public String editarProducto(@ModelAttribute("producto") Producto update,
                                 @RequestParam(value = "image", required = false) MultipartFile image,
                                 @RequestParam(value = "barcode", required = false) Long barcode,
                                 @RequestParam(value = "barcodeImage", required = false) String barcodeImage,
                                 @RequestParam Map<String, String> storeQuantities, Model model) throws Exception {

        Producto producto = productoService.getById(update.getId());

        if (!producto.getPrecioEfectivo().equals(update.getPrecioEfectivo()) ||
                !producto.getPrecioDebito().equals(update.getPrecioDebito()) ||
                !producto.getPrecioCredito().equals(update.getPrecioCredito())) {
            update.setUltActPrecio(LocalDateTime.now());
        }

        if (image.getOriginalFilename() != "") {
            String imageName = image.getOriginalFilename();
            fileService.storeImage(image, imageName);
            if (producto.getImagen() != null) {
                fileService.deleteImage(producto.getImagen().getNombre());
                Imagen imagenEncontrada = producto.getImagen();
                imagenEncontrada.setNombre(imageName);
                update.setImagen(imagenEncontrada);
            } else {
                Imagen imagen = imagenService.save(new Imagen(imageName));
                update.setImagen(imagen);
            }
        }

        if (barcodeImage != null && !barcodeImage.isEmpty()) {
            String barcodeName = barcode + ".png";
            byte[] barcodeData = Base64.getDecoder().decode(barcodeImage.split(",")[1]);
            fileService.storeBarcode(barcodeData, barcodeName);

            if (producto.getBarcode() != null){
                fileService.deleteBarcode(producto.getBarcode().getImagen());
                Barcode barcodeEncontrado = producto.getBarcode();
                barcodeEncontrado.setCodigo(barcode);
                barcodeEncontrado.setImagen(barcodeName);
                update.setBarcode(barcodeEncontrado);
            } else {
                Barcode barcodeEntity = barcodeService.save(new Barcode(barcodeName, barcode));
                update.setBarcode(barcodeEntity);
            }
        }

        try {
            productoService.save(update);
        } catch (ExceptionCodigoRepetido e){
            return "redirect:/administrador/panel/productos/registrar?error=" + e.getMessage();
        }

        // Distribucion del Stock
        List<Local> sucursales = localService.findAll();
        for (Local sucursal : sucursales) {
            if (storeQuantities.get(sucursal.getId().toString()) != null) {
                Integer quantity = !storeQuantities.get(sucursal.getId().toString()).isEmpty() ? Integer.parseInt(storeQuantities.get(sucursal.getId().toString())) : null;

                Stock stockEncontrado = stockService.findByLocalAndProducto(sucursal, producto);
                if (stockEncontrado != null && stockEncontrado.getCantidad() != quantity) {
                    stockEncontrado.setCantidad(quantity);
                    stockEncontrado.setUltActStock(LocalDateTime.now());
                    stockService.save(stockEncontrado);
                }
                if (quantity != null){
                    if (stockEncontrado == null && quantity >= 0) {
                        Stock stock = new Stock(producto, sucursal, quantity, LocalDateTime.now());
                        stockService.save(stock);
                    }
                }
                if (quantity == null && stockEncontrado != null){
                    stockService.delete(stockEncontrado);
                }
            }
        }

        return "redirect:/administrador/panel/productos";
    }

    @PostMapping("/local/administrador/producto/registrar")
    public String registrarProductoLocal(@ModelAttribute("nuevoProducto") Producto producto,
                                    @RequestParam("cantidad") Integer cantidad,
                                    @RequestParam("local") Long id) throws ExceptionCodigoRepetido {

        producto.setUltActPrecio(LocalDateTime.now());
        productoService.save(producto);

        Stock stock = new Stock();
        stock.setProducto(producto);
        stock.setCantidad(cantidad);
        stock.setLocal(localService.getById(id));
        stock.setUltActStock(LocalDateTime.now());
        stockService.save(stock);
        return "redirect:/local/" + id;
    }

    @GetMapping("/administrador/producto/{id}/eliminar")
    public String eliminarProducto(@PathVariable("id") Long id) throws IOException {
        Producto producto = productoService.getById(id);
        List<Stock> stocks = stockService.findAllByProducto(producto);
        Imagen imagen = producto.getImagen();
        Barcode barcode = producto.getBarcode();

        for (Stock stock : stocks){
            stockService.delete(stock);
        }

        if (imagen != null) {
            fileService.deleteImage(producto.getImagen().getNombre());
        }

        if (barcode != null) {
            fileService.deleteBarcode(producto.getBarcode().getImagen());
        }

        productoService.delete(producto);
        return "redirect:/administrador/panel/productos";
    }

    @GetMapping("/administrador/panel/productos")
    public String verProductos(@RequestParam Map<String, Object> params, Model model){

        // Selects
        List<Marca> marcas = marcaService.findAll();
        List<Rubro> rubros = rubroService.findAll();
        List<Proveedor> proveedores = proveedorService.findAll();
        List<String> cantidadDeRegitrosPorPaginas = Arrays.asList("10", "20", "30", "40", "50", "Todos");
        // Fin selects

        // Paginacion
        int recordsQuantity;
        if (params.get("recordsQuantity") != null && params.get("recordsQuantity").toString().equals("Todos")) {
            recordsQuantity = Integer.MAX_VALUE;
        } else {
            recordsQuantity = params.get("recordsQuantity") != null ? Integer.parseInt(params.get("recordsQuantity").toString()) : Integer.parseInt(cantidadDeRegitrosPorPaginas.get(0));
        }

        int page = params.get("page") != null ? (Integer.parseInt(params.get("page").toString()) - 1) : 0;

        PageRequest pageRequest = PageRequest.of(page, recordsQuantity, Sort.by(Sort.Direction.DESC, "id"));
        // Fin Paginacion

        // Filtrado
        Proveedor proveedor = params.get("proveedor") != null ? proveedorService.getById(Long.valueOf(params.get("proveedor").toString())) : null;
        Rubro rubro = params.get("rubro") != null ? rubroService.getById(Long.valueOf(params.get("rubro").toString())) : null;
        Marca marca = params.get("marca") != null ? marcaService.getById(Long.valueOf(params.get("marca").toString())) : null;

        Page<Producto> productPage;
        if (proveedor == null && rubro == null && marca == null) {
            productPage = productoService.findAll(pageRequest);
        } else {
            productPage = productoService.findAllWithFilters(proveedor, rubro, marca, pageRequest);
        }
        // Fin Filtrado

        int totalPage = productPage.getTotalPages();
        if (totalPage > 0) {
            List<Integer> pages = IntStream.rangeClosed(1, totalPage).boxed().collect(Collectors.toList());
            model.addAttribute("pages", pages);
        }
        List<Producto> listaProductos = productPage.getContent();

        model.addAttribute("current", page + 1);
        model.addAttribute("next", page + 2);
        model.addAttribute("prev", page);
        model.addAttribute("last", totalPage);
        model.addAttribute("cantidadDeRegitrosPorPaginas", cantidadDeRegitrosPorPaginas);
        model.addAttribute("recordsQuantity", (recordsQuantity == Integer.MAX_VALUE ? "Todos" : recordsQuantity));

        model.addAttribute("listaProductos", listaProductos);

        model.addAttribute("marcas", marcas);
        model.addAttribute("brand", (params.get("marca") != null ? Long.valueOf(params.get("marca").toString()) : 0));

        model.addAttribute("rubros", rubros);
        model.addAttribute("category", (params.get("rubro") != null ? Long.valueOf(params.get("rubro").toString()) : 0));

        model.addAttribute("proveedores", proveedores);
        model.addAttribute("provider", (params.get("proveedor") != null ? Long.valueOf(params.get("proveedor").toString()) : 0));

        return "listado-Productos";
    }

    @GetMapping("/administrador/panel/productos/modificacion/rapida")
    public String verProductosModificacionRapida(@RequestParam Map<String, Object> params, Model model){

        // Selects
        List<Marca> marcas = marcaService.findAll();
        List<Rubro> rubros = rubroService.findAll();
        List<Proveedor> proveedores = proveedorService.findAll();
        List<String> cantidadDeRegitrosPorPaginas = Arrays.asList("10", "20", "30", "40", "50", "Todos");
        // Fin selects

        // Paginacion
        int recordsQuantity;
        if (params.get("recordsQuantity") != null && params.get("recordsQuantity").toString().equals("Todos")) {
            recordsQuantity = Integer.MAX_VALUE;
        } else {
            recordsQuantity = params.get("recordsQuantity") != null ? Integer.parseInt(params.get("recordsQuantity").toString()) : Integer.parseInt(cantidadDeRegitrosPorPaginas.get(0));
        }

        int page = params.get("page") != null ? (Integer.parseInt(params.get("page").toString()) - 1) : 0;

        PageRequest pageRequest = PageRequest.of(page, recordsQuantity, Sort.by(Sort.Direction.DESC, "id"));
        // Fin Paginacion

        // Filtrado
        Proveedor proveedor = params.get("proveedor") != null ? proveedorService.getById(Long.valueOf(params.get("proveedor").toString())) : null;
        Rubro rubro = params.get("rubro") != null ? rubroService.getById(Long.valueOf(params.get("rubro").toString())) : null;
        Marca marca = params.get("marca") != null ? marcaService.getById(Long.valueOf(params.get("marca").toString())) : null;

        Page<Producto> productPage;
        if (proveedor == null && rubro == null && marca == null) {
            productPage = productoService.findAll(pageRequest);
        } else {
            productPage = productoService.findAllWithFilters(proveedor, rubro, marca, pageRequest);
        }
        // Fin Filtrado

        int totalPage = productPage.getTotalPages();
        if (totalPage > 0) {
            List<Integer> pages = IntStream.rangeClosed(1, totalPage).boxed().collect(Collectors.toList());
            model.addAttribute("pages", pages);
        }
        List<Producto> listaProductos = productPage.getContent();

        model.addAttribute("current", page + 1);
        model.addAttribute("next", page + 2);
        model.addAttribute("prev", page);
        model.addAttribute("last", totalPage);
        model.addAttribute("cantidadDeRegitrosPorPaginas", cantidadDeRegitrosPorPaginas);
        model.addAttribute("recordsQuantity", (recordsQuantity == Integer.MAX_VALUE ? "Todos" : recordsQuantity));

        model.addAttribute("listaProductos", listaProductos);

        model.addAttribute("marcas", marcas);
        model.addAttribute("brand", (params.get("marca") != null ? Long.valueOf(params.get("marca").toString()) : null));

        model.addAttribute("rubros", rubros);
        model.addAttribute("category", (params.get("rubro") != null ? Long.valueOf(params.get("rubro").toString()) : null));

        model.addAttribute("proveedores", proveedores);
        model.addAttribute("provider", (params.get("proveedor") != null ? Long.valueOf(params.get("proveedor").toString()) : null));

        return "modificar-productos-rapida";
    }

    @PostMapping("/administrador/panel/productos/modificacion/rapida")
    public String modificacionRapida(@RequestParam("radio") String opcion,
                                     @RequestParam(value = "selectedProduct", required = false) List<Long> selectedProductsIds,
                                     @RequestParam(value= "porcentajeEfectivo", required = false) Integer porcentajeEfectivo,
                                     @RequestParam(value= "porcentajeDebito", required = false) Integer porcentajeDebito,
                                     @RequestParam(value= "porcentajeCredito", required = false) Integer porcentajeCredito) throws Exception{

        if (selectedProductsIds != null){
            List<Producto> productosUpdate = productoService.findAllByIds(selectedProductsIds);
            if (opcion.equals("AUMENTAR")) {
                productoService.incrementarPrecio(porcentajeEfectivo, porcentajeDebito, porcentajeCredito, productosUpdate);
            }
            if (opcion.equals("DISMINUIR")) {
                productoService.decrementarPrecio(porcentajeEfectivo, porcentajeDebito, porcentajeCredito, productosUpdate);
            }
        }

        return "redirect:/administrador/panel/productos/modificacion/rapida";
    }

    @GetMapping(value = "/administrador/panel/productos/exportar")
    public ResponseEntity exportToExcel(@RequestParam Map<String, Object> params) {

        // Paginacion
        int recordsQuantity;
        if (params.get("recordsQuantity") != null && params.get("recordsQuantity").toString().equals("Todos")) {
            recordsQuantity = Integer.MAX_VALUE;
        } else {
            recordsQuantity = params.get("recordsQuantity") != null ? Integer.parseInt(params.get("recordsQuantity").toString()) : 10;
        }

        PageRequest pageRequest = PageRequest.of(0, recordsQuantity, Sort.by(Sort.Direction.DESC, "id"));
        // Fin Paginacion

        // Filtrado
        Proveedor proveedor = params.get("proveedor") != null ? proveedorService.getById(Long.valueOf(params.get("proveedor").toString())) : null;
        Rubro rubro = params.get("rubro") != null ? rubroService.getById(Long.valueOf(params.get("rubro").toString())) : null;
        Marca marca = params.get("marca") != null ? marcaService.getById(Long.valueOf(params.get("marca").toString())) : null;

        Page<Producto> productos;
        if (proveedor == null && rubro == null && marca == null) {
            productos = productoService.findAll(pageRequest);
        } else {
            productos = productoService.findAllWithFilters(proveedor, rubro, marca, pageRequest);
        }
        // Fin Filtrado

        List<Producto> listaProductos = productos.getContent();

        // Export to Excel
        byte[] excelBytes;
        try {
            excelBytes = fileService.exportProductsToExcel(listaProductos);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "stock.xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excelBytes);
    }

    @GetMapping("/administrador/panel/productos/modificacion/masiva")
    public String irModificacionMasiva(@RequestParam Map<String, Object> params, Model model) {

        // Selects
        List<Marca> marcas = marcaService.findAll();
        List<Rubro> rubros = rubroService.findAll();
        List<Proveedor> proveedores = proveedorService.findAll();
        List<String> cantidadDeRegitrosPorPaginas = Arrays.asList("10", "20", "30", "40", "50", "Todos");
        // Fin selects

        // Paginacion
        int recordsQuantity;
        if (params.get("recordsQuantity") != null && params.get("recordsQuantity").toString().equals("Todos")) {
            recordsQuantity = Integer.MAX_VALUE;
        } else {
            recordsQuantity = params.get("recordsQuantity") != null ? Integer.parseInt(params.get("recordsQuantity").toString()) : Integer.parseInt(cantidadDeRegitrosPorPaginas.get(0));
        }

        int page = params.get("page") != null ? (Integer.parseInt(params.get("page").toString()) - 1) : 0;

        PageRequest pageRequest = PageRequest.of(page, recordsQuantity, Sort.by(Sort.Direction.DESC, "id"));
        // Fin Paginacion

        // Filtrado
        Proveedor proveedor = params.get("proveedor") != null ? proveedorService.getById(Long.valueOf(params.get("proveedor").toString())) : null;
        Rubro rubro = params.get("rubro") != null ? rubroService.getById(Long.valueOf(params.get("rubro").toString())) : null;
        Marca marca = params.get("marca") != null ? marcaService.getById(Long.valueOf(params.get("marca").toString())) : null;

        Page<Producto> productPage;
        if (proveedor == null && rubro == null && marca == null) {
            productPage = productoService.findAll(pageRequest);
        } else {
            productPage = productoService.findAllWithFilters(proveedor, rubro, marca, pageRequest);
        }
        // Fin Filtrado

        int totalPage = productPage.getTotalPages();
        if (totalPage > 0) {
            List<Integer> pages = IntStream.rangeClosed(1, totalPage).boxed().collect(Collectors.toList());
            model.addAttribute("pages", pages);
        }
        List<Producto> listaProductos = productPage.getContent();

        model.addAttribute("current", page + 1);
        model.addAttribute("next", page + 2);
        model.addAttribute("prev", page);
        model.addAttribute("last", totalPage);
        model.addAttribute("cantidadDeRegitrosPorPaginas", cantidadDeRegitrosPorPaginas);
        model.addAttribute("recordsQuantity", (recordsQuantity == Integer.MAX_VALUE ? "Todos" : recordsQuantity));

        model.addAttribute("listaProductos", listaProductos);

        model.addAttribute("marcas", marcas);
        model.addAttribute("brand", (params.get("marca") != null ? Long.valueOf(params.get("marca").toString()) : null));

        model.addAttribute("rubros", rubros);
        model.addAttribute("category", (params.get("rubro") != null ? Long.valueOf(params.get("rubro").toString()) : null));

        model.addAttribute("proveedores", proveedores);
        model.addAttribute("provider", (params.get("proveedor") != null ? Long.valueOf(params.get("proveedor").toString()) : null));

        return "modificar-productos-masiva";
    }

}
