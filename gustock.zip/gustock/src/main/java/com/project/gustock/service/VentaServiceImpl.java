package com.project.gustock.service;

import com.project.gustock.model.Venta;
import com.project.gustock.repository.VentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VentaServiceImpl implements VentaService{

    @Autowired
    VentaRepository ventaRepository;

    @Override
    public void save(Venta venta){ventaRepository.save(venta);}
}
