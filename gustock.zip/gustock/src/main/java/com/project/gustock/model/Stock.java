package com.project.gustock.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
public class Stock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Local local;

    @ManyToOne
    private Producto producto;

    private Integer cantidad;

    @DateTimeFormat(pattern="yyyy-MM-dd'T'HH:mm")
    private LocalDateTime ultActStock;

    public Stock(Producto producto, Local local, int quantity, LocalDateTime date) {
        this.producto = producto;
        this.local = local;
        this.cantidad = quantity;
        this.ultActStock = date;
    }

    public Stock() {

    }
}
