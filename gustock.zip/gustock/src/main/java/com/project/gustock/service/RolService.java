package com.project.gustock.service;

import com.project.gustock.model.Rol;
import java.util.List;

public interface RolService {

    List<Rol> findAll();

    Rol getRolByName(String name);

}
