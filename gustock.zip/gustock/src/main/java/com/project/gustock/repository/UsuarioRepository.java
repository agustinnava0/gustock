package com.project.gustock.repository;

import com.project.gustock.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Usuario findUsuarioById(Long id);

    Usuario findByUsername(String username);
}
