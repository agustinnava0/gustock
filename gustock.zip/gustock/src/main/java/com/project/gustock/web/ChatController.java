package com.project.gustock.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ChatController {

    @GetMapping("/mensajeria")
    public String iraChat(){

        return "chat";
    }
}
