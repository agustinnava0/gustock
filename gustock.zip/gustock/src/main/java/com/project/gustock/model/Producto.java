package com.project.gustock.model;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String codigo;

    @OneToOne(cascade = CascadeType.REMOVE)
    private Imagen imagen;

    @OneToOne(cascade = CascadeType.REMOVE)
    private Barcode barcode;

    private String descripcion;

    private Double precioEfectivo;
    private Double precioDebito;
    private Double precioCredito;

    @DateTimeFormat(pattern="yyyy-MM-dd'T'HH:mm")
    private LocalDateTime ultActPrecio;

    @ManyToOne
    private Proveedor proveedor;

    @ManyToOne
    private Rubro rubro;

    @ManyToOne
    private Marca marca;

}
