package com.project.gustock.service;

import com.project.gustock.model.Local;
import com.project.gustock.model.Producto;
import com.project.gustock.model.Stock;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

public interface FileService {

    void storeImage(MultipartFile file, String imagen) throws IOException;

    void deleteImage(String imagen) throws IOException;

    void deleteBarcode(String imagen) throws IOException;

    Resource getImage(String imagen) throws MalformedURLException;

    void storeBarcode(byte[] barcodeData, String barcode) throws IOException;

    byte[] exportToExcel(List<Stock> listaProductos, Local local) throws IOException;

    byte[] exportProductsToExcel(List<Producto> listaProductos) throws IOException;
}
