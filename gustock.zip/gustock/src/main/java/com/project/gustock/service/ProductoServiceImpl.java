package com.project.gustock.service;

import com.project.gustock.exceptions.ExceptionCodigoRepetido;
import com.project.gustock.exceptions.ExceptionProductoNoEncontrado;
import com.project.gustock.model.Marca;
import com.project.gustock.model.Producto;
import com.project.gustock.model.Proveedor;
import com.project.gustock.model.Rubro;
import com.project.gustock.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductoServiceImpl implements ProductoService{

    @Autowired
    ProductoRepository productoRepository;

    @Override
    public Producto save(Producto producto) throws ExceptionCodigoRepetido {
        if (producto.getId() == null && productoRepository.findByCodigo(producto.getCodigo()) != null){
            throw new ExceptionCodigoRepetido();
        }
        return productoRepository.save(producto);
    }

    @Override
    public void delete(Producto producto) {productoRepository.delete(producto);}

    @Override
    public Producto getById(Long id) {return productoRepository.getReferenceById(id);}

    @Override
    public Page<Producto> findAll(Pageable pageable){return productoRepository.findAll(pageable);}

    @Override
    public Producto findByCodigo(String codigo) throws ExceptionProductoNoEncontrado {
        if (productoRepository.findByCodigo(codigo) == null){
            throw new ExceptionProductoNoEncontrado();
        }
        return productoRepository.findByCodigo(codigo);
    }

    @Override
    public Producto findByCodigoOrBarcode_Codigo(String codigo, Long barcode) throws ExceptionProductoNoEncontrado {
        if (productoRepository.findByCodigoOrBarcode_Codigo(codigo, barcode) == null){
            throw new ExceptionProductoNoEncontrado();
        }
        return productoRepository.findByCodigoOrBarcode_Codigo(codigo, barcode);
    }

    @Override
    public List<Producto> findAllByIds(List<Long> productIds) {
        List<Producto> productos = new ArrayList<>();

        for (Long productoId : productIds) {
            Producto producto = productoRepository.getReferenceById(productoId);
            productos.add(producto);
        }

        return productos;
    }

    @Override
    public Page<Producto> findAllWithFilters(Proveedor proveedor, Rubro rubro, Marca marca, Pageable pageable) {

        if (rubro.getId() == 0 && marca.getId() == 0 && proveedor.getId() == 0) {
            return productoRepository.findAll(pageable);
        }

        if (rubro.getId() == 0) {
            if (marca.getId() == 0) {
                return productoRepository.findAllByProveedor(pageable, proveedor);
            }
            if (proveedor.getId() == 0) {
                return productoRepository.findAllByMarca(pageable, marca);
            }
            return productoRepository.findAllByMarcaAndProveedor(pageable, marca, proveedor);
        }

        if (marca.getId() == 0) {
            if (proveedor.getId() == 0) {
                return productoRepository.findAllByRubro(pageable, rubro);
            }
            return productoRepository.findAllByRubroAndProveedor(pageable, rubro, proveedor);
        }

        if (proveedor.getId() == 0) {
            return productoRepository.findAllByRubroAndMarca(pageable, rubro, marca);
        }

        return productoRepository.findAllByProveedorAndRubroAndMarca(pageable, proveedor, rubro, marca);

    }

    @Override
    public void incrementarPrecio(Integer porcentajeEfectivo, Integer porcentajeDebito, Integer porcentajeCredito, List<Producto> productosUpdate) {
        for (Producto producto : productosUpdate){
            Boolean changeDate = false;
            if(porcentajeEfectivo != null){
                Double precio = producto.getPrecioEfectivo();
                Double nuevoPrecio = incrementar(precio, porcentajeEfectivo);
                producto.setPrecioEfectivo(nuevoPrecio);
                changeDate = true;
            }
            if(porcentajeDebito != null){
                Double precio = producto.getPrecioDebito();
                Double nuevoPrecio = incrementar(precio, porcentajeDebito);
                producto.setPrecioDebito(nuevoPrecio);
                changeDate = true;
            }
            if(porcentajeCredito != null){
                Double precio = producto.getPrecioCredito();
                Double nuevoPrecio = incrementar(precio, porcentajeCredito);
                producto.setPrecioCredito(nuevoPrecio);
                changeDate = true;
            }
            if (changeDate) producto.setUltActPrecio(LocalDateTime.now());
            productoRepository.save(producto);
        }
    }

    @Override
    public void decrementarPrecio(Integer porcentajeEfectivo, Integer porcentajeDebito, Integer porcentajeCredito, List<Producto> productosUpdate) {
        for (Producto producto : productosUpdate){
            Boolean changeDate = false;
            if(porcentajeEfectivo != null){
                Double precio = producto.getPrecioEfectivo();
                Double nuevoPrecio = decrementar(precio, porcentajeEfectivo);
                producto.setPrecioEfectivo(nuevoPrecio);
                changeDate = true;
            }
            if(porcentajeDebito != null){
                Double precio = producto.getPrecioDebito();
                Double nuevoPrecio = decrementar(precio, porcentajeDebito);
                producto.setPrecioDebito(nuevoPrecio);
                changeDate = true;
            }
            if(porcentajeCredito != null){
                Double precio = producto.getPrecioCredito();
                Double nuevoPrecio = decrementar(precio, porcentajeCredito);
                producto.setPrecioCredito(nuevoPrecio);
                changeDate = true;
            }
            if (changeDate) producto.setUltActPrecio(LocalDateTime.now());
            productoRepository.save(producto);
        }
    }

    public Double incrementar(Double precio, Integer porcentaje){
        return precio = precio + ((double)porcentaje/100 * precio);
    }

    public Double decrementar(Double precio, Integer porcentaje){
        return precio = precio - ((double)porcentaje/100* precio);
    }

}
