package com.project.gustock.service;

import com.project.gustock.model.Usuario;

import java.util.List;

public interface UsuarioService {

    void save(Usuario usuario);

    void delete(Usuario usuario);

    List<Usuario> findAll();

    Usuario findUsuarioById(Long id);

    Usuario findByUsername(String name);
}
