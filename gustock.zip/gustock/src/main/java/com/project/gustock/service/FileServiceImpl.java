package com.project.gustock.service;

import com.project.gustock.model.Local;
import com.project.gustock.model.Producto;
import com.project.gustock.model.Stock;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

@Service
public class FileServiceImpl implements FileService{

    @Value("${product.image.directory}")
    private String imageDirectory;

    @Value("${barcode.image.directory}")
    private String barcodeDirectory;

    public void storeImage(MultipartFile file, String imagen) throws IOException {
        Path imagePath = Paths.get(imageDirectory, imagen);
        Files.write(imagePath, file.getBytes());
    }

    @Override
    public void storeBarcode(byte[] barcodeData, String barcode) throws IOException {
        Path imagePath = Paths.get(barcodeDirectory, barcode);
        Files.write(imagePath, barcodeData);
    }

    public void deleteImage(String imagen) throws IOException {
        Path imagePath = Paths.get(imageDirectory, imagen);
        Files.delete(imagePath);
    }

    @Override
    public void deleteBarcode(String imagen) throws IOException {
        Path imagePath = Paths.get(barcodeDirectory, imagen);
        Files.delete(imagePath);
    }

    public Resource getImage(String imagen) throws MalformedURLException {
        Path imagePath = Paths.get(imageDirectory, imagen);
        Resource imageResource = new UrlResource(imagePath.toUri());
        if (imageResource.exists() || imageResource.isReadable()) {
            return imageResource;
        } else {
            throw new RuntimeException("Could not retrieve image file: " + imagen);
        }
    }

    public byte[] exportToExcel(List<Stock> listaProductos, Local local) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Stock");

        // Format the amount as currency using the Argentine locale
        NumberFormat argentineFormat = DecimalFormat.getCurrencyInstance(new Locale("es", "AR"));

        // Create header row
        String[] headers = {"Código", "Descripción", "Cantidad", "Efectivo", "Débito", "Crédito"};
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            sheet.setColumnWidth(i, 20 * 256);
        }

        // Create a new cell style
        CellStyle centerStyle = workbook.createCellStyle();
        centerStyle.setAlignment(HorizontalAlignment.CENTER);

        // Create data rows
        int rowNum = 1;
        for (Stock stock : listaProductos) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(stock.getProducto().getCodigo());
            row.createCell(1).setCellValue(stock.getProducto().getDescripcion());

            row.createCell(2).setCellValue(stock.getCantidad());
            row.getCell(2).setCellStyle(centerStyle);

            row.createCell(3).setCellValue(argentineFormat.format(stock.getProducto().getPrecioEfectivo()));
            row.createCell(4).setCellValue(argentineFormat.format(stock.getProducto().getPrecioDebito()));
            row.createCell(5).setCellValue(argentineFormat.format(stock.getProducto().getPrecioCredito()));
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        workbook.close();

        return baos.toByteArray();
    }

    @Override
    public byte[] exportProductsToExcel(List<Producto> listaProductos) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Productos");

        // Format the amount as currency using the Argentine locale
        NumberFormat argentineFormat = DecimalFormat.getCurrencyInstance(new Locale("es", "AR"));

        // Create header row
        String[] headers = {"Código", "Descripción", "Efectivo", "Débito", "Crédito"};
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            sheet.setColumnWidth(i, 20 * 256);
        }

        // Create data rows
        int rowNum = 1;
        for (Producto producto : listaProductos) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(producto.getCodigo());
            row.createCell(1).setCellValue(producto.getDescripcion());
            row.createCell(2).setCellValue(argentineFormat.format(producto.getPrecioEfectivo()));
            row.createCell(3).setCellValue(argentineFormat.format(producto.getPrecioDebito()));
            row.createCell(4).setCellValue(argentineFormat.format(producto.getPrecioCredito()));
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        workbook.close();

        return baos.toByteArray();
    }

}
