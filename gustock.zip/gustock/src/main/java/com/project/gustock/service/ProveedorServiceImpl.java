package com.project.gustock.service;

import com.project.gustock.model.Local;
import com.project.gustock.model.Proveedor;
import com.project.gustock.repository.ProveedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProveedorServiceImpl implements ProveedorService {

    @Autowired
    ProveedorRepository proveedorRepository;

    @Override
    public void save(Proveedor proveedor){proveedorRepository.save(proveedor);}

    @Override
    public void delete(Proveedor proveedor){proveedorRepository.delete(proveedor);}

    @Override
    public List<Proveedor> findAll(){return proveedorRepository.findAll();}

    @Override
    public Proveedor getById(Long id){return proveedorRepository.getReferenceById(id);}
}
