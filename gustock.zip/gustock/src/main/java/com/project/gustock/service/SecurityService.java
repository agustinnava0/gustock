package com.project.gustock.service;

public interface SecurityService {

    boolean isAuthenticated();
}
