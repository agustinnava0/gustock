package com.project.gustock.repository;

import com.project.gustock.model.Marca;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarcaRepository extends JpaRepository<Marca, Long> {

    Marca findByDescripcion(String descripcion);
}
