package com.project.gustock.repository;

import com.project.gustock.model.Imagen;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImagenRepository  extends JpaRepository<Imagen, Long> {
}
