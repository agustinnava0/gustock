package com.project.gustock.repository;

import com.project.gustock.model.Local;
import com.project.gustock.model.TipoLocal;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LocalRepository extends JpaRepository<Local, Long> {

    List<Local> findAllByTipo(TipoLocal tipo);

}
