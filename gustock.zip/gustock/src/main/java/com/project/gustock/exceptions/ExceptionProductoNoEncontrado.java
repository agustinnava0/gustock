package com.project.gustock.exceptions;

public class ExceptionProductoNoEncontrado extends Exception{

    public ExceptionProductoNoEncontrado(){super("Lo sentimos, el producto no se encuentra en el sistema");}
}
