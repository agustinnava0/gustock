package com.project.gustock.security;

public enum WebUserRole {

    ADMINISTRADOR,
    ENCARGADO,
    USUARIO
}
