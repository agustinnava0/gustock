package com.project.gustock.model;

public enum TipoPrecio {

    CONTADO, DEBITO, CREDITO
}
