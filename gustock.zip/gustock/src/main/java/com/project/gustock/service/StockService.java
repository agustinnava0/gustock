package com.project.gustock.service;

import com.project.gustock.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

public interface StockService {

    void save(Stock stock);

    void delete(Stock stock);

    Stock getById(Long id);

    Stock findByLocalAndProducto(Local local, Producto producto);

    List<Stock> findAllByLocal(Local local);

    List<Stock> findAllByProducto(Producto producto);

    Page<Stock> findAllByLocal(Pageable pageable, Local local);

    Page<Stock> findAllByLocalWithFilters(Pageable pageable, Local local, Proveedor proveedor, Rubro rubro, Marca marca);

}
