package com.project.gustock.exceptions;

public class ExceptionCodigoRepetido extends Exception{

    public ExceptionCodigoRepetido(){super("Error: Ya existe un producto con ese codigo");}
}
