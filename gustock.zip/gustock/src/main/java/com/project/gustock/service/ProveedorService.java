package com.project.gustock.service;

import com.project.gustock.model.Local;
import com.project.gustock.model.Proveedor;

import java.util.List;

public interface ProveedorService {

    void save(Proveedor proveedor);
    void delete(Proveedor proveedor);
    List<Proveedor> findAll();
    Proveedor getById(Long id);
}
