package com.project.gustock.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Barcode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String imagen;

    private Long codigo;

    public Barcode(String imagen, Long codigo){
        this.imagen = imagen;
        this.codigo = codigo;
    }

    public Barcode() {

    }
}
