package com.project.gustock.web;

import com.project.gustock.exceptions.ExceptionProductoNoEncontrado;
import com.project.gustock.model.*;
import com.project.gustock.service.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Controller
public class MainController {

    @Autowired
    private SecurityService securityService;
    @Autowired
    private LocalService localService;
    @Autowired
    private ProductoService productoService;
    @Autowired
    private StockService stockService;
    @Autowired
    private ProveedorService proveedorService;
    @Autowired
    private UsuarioService usuarioService;
    @Autowired
    private RubroService rubroService;
    @Autowired
    private MarcaService marcaService;
    @Autowired
    private RolService rolService;

    @GetMapping("/login")
    public String IraLogin(){
        if (securityService.isAuthenticated()) {
            return "redirect:/";
        }
        return "login";
    }

    @GetMapping(value = "/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/login";
    }

    @GetMapping({"/","/inicio"})
    public String IraHome(Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Usuario usuario = usuarioService.findByUsername(authentication.getName());

        List<Local> locales = localService.findAllByTipo(TipoLocal.LOCAL);
        List<Local> depositos = localService.findAllByTipo(TipoLocal.DEPOSITO);

        model.addAttribute("usuario", usuario);
        model.addAttribute("locales", locales);
        model.addAttribute("depositos", depositos);
        return "inicio";
    }

    @GetMapping("/buscar/producto")
    public String buscarProducto(@RequestParam(value = "codeSearch") String codigo, Model model) {
        Producto producto;
        Long barcode = Long.valueOf(0);

        if (codigo.length() == 13 && codigo.matches("[0-9]+")){
            barcode = Long.valueOf(codigo);
        }

        try {
            producto = productoService.findByCodigoOrBarcode_Codigo(codigo, barcode);
        } catch (ExceptionProductoNoEncontrado e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("producto", new Producto());
            model.addAttribute("stocks", new ArrayList<Stock>());
            return "ver-producto";
        }

        List<Stock> stocks = stockService.findAllByProducto(producto);

        model.addAttribute("producto", producto);
        model.addAttribute("stocks", stocks);
        return "ver-producto";
    }

    @GetMapping("/administrador/panel")
    public String IraPanel(@RequestParam(value = "exito", required = false) String exito,
                           @RequestParam(value = "error", required = false) String error, Model model){

        Local local = new Local();
        List<Local> locales = localService.findAll();

        Proveedor proveedor = new Proveedor();
        List<Proveedor> proveedores = proveedorService.findAll();

        Usuario usuario = new Usuario();
        List<Usuario> usuarios = usuarioService.findAll();

        Rubro rubro = new Rubro();
        List<Rubro> rubros = rubroService.findAll();

        Marca marca = new Marca();
        List<Marca> marcas = marcaService.findAll();

        List<Rol> roles = rolService.findAll();

        model.addAttribute("exito", exito);

        model.addAttribute("roles", roles);
        model.addAttribute("marcas", marcas);
        model.addAttribute("rubros", rubros);
        model.addAttribute("locales", locales);
        model.addAttribute("usuarios", usuarios);
        model.addAttribute("proveedores", proveedores);

        model.addAttribute("nuevoUsuario", usuario);
        model.addAttribute("nuevaMarca", marca);
        model.addAttribute("nuevoRubro", rubro);
        model.addAttribute("nuevoLocal", local);
        model.addAttribute("nuevoProveedor", proveedor);

        return "panel";
    }

}
