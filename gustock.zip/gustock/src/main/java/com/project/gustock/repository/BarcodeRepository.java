package com.project.gustock.repository;

import com.project.gustock.model.Barcode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BarcodeRepository  extends JpaRepository<Barcode, Long> {

}
