package com.project.gustock.service;

import com.project.gustock.model.Imagen;

public interface ImagenService {

    Imagen save(Imagen imagen);

    void delete(Imagen imagen);

}
