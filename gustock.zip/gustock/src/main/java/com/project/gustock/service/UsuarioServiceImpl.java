package com.project.gustock.service;

import com.project.gustock.model.Bandeja;
import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Rol;
import com.project.gustock.model.Usuario;
import com.project.gustock.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class UsuarioServiceImpl implements UsuarioService{

    @Autowired
    UsuarioRepository usuarioRepository;
    @Autowired
    PasswordEncoder bCryptPasswordEncoder;
    @Autowired
    NotificacionService notificacionService;
    @Autowired
    BandejaService bandejaService;
    @Autowired
    RolService rolService;

    @Override
    public void save(Usuario usuario){

        Set<Rol> roles = new HashSet<>();
        if (usuario.getId() == null) {
            usuario.setPassword(bCryptPasswordEncoder.encode(usuario.getPassword()));
            roles.add(this.rolService.getRolByName("ROLE_USUARIO"));
            usuario.setRoles(new HashSet<>(roles));

            usuarioRepository.save(usuario);
        } else {
            roles = usuario.getRoles();
            usuario.setRoles(roles);
        }
        usuarioRepository.save(usuario);
    }

    @Override
    public void delete(Usuario usuario) {usuarioRepository.delete(usuario);}

    @Override
    public List<Usuario> findAll() {return usuarioRepository.findAll();}

    @Override
    public Usuario findUsuarioById(Long id) {return usuarioRepository.findUsuarioById(id);}

    @Override
    public Usuario findByUsername(String name) {return usuarioRepository.findByUsername(name);}

}
