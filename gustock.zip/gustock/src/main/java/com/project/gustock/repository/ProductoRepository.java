package com.project.gustock.repository;

import com.project.gustock.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

    Producto findByCodigo(String codigo);

    Producto findByCodigoOrBarcode_Codigo(String codigo, Long barcode);

    List<Producto> findAll();

    Page<Producto> findAll(Pageable pageable);

    Page<Producto> findAllByProveedor(Pageable pageable, Proveedor proveedor);

    Page<Producto> findAllByMarca(Pageable pageable, Marca marca);

    Page<Producto> findAllByRubro(Pageable pageable, Rubro rubro);

    Page<Producto> findAllByMarcaAndProveedor(Pageable pageable, Marca marca, Proveedor proveedor);

    Page<Producto> findAllByRubroAndProveedor(Pageable pageable, Rubro rubro, Proveedor proveedor);

    Page<Producto> findAllByRubroAndMarca(Pageable pageable, Rubro rubro, Marca marca);

    Page<Producto> findAllByProveedorAndRubroAndMarca(Pageable pageable, Proveedor proveedor, Rubro rubro, Marca marca);

}
