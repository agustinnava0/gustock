package com.project.gustock.service;

import com.project.gustock.model.*;
import com.project.gustock.repository.StockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class StockServiceImpl implements StockService{

    @Autowired
    StockRepository stockRepository;

    @Override
    public void save(Stock stock) {stockRepository.save(stock);}

    @Override
    public void delete(Stock stock) {stockRepository.delete(stock);}

    @Override
    public Stock getById(Long id) {return stockRepository.getReferenceById(id);}

    @Override
    public Stock findByLocalAndProducto(Local local, Producto producto) {return stockRepository.findByLocalAndProducto(local, producto);}

    @Override
    public List<Stock> findAllByLocal(Local local) {return stockRepository.findAllByLocal(local);}

    @Override
    public List<Stock> findAllByProducto(Producto producto) {return stockRepository.findAllByProducto(producto);}

    @Override
    public Page<Stock> findAllByLocal(Pageable pageable, Local local) {return stockRepository.findAllByLocal(pageable, local);}

    @Override
    public Page<Stock> findAllByLocalWithFilters(Pageable pageable, Local local, Proveedor proveedor, Rubro rubro, Marca marca) {

        //NOTA: proveedor, rubro, y marca no devuelven el null del controlador

        if (rubro.getId() == 0 && marca.getId() == 0 && proveedor.getId() == 0) {
            return stockRepository.findAllByLocal(pageable, local);
        }

        if (rubro.getId() == 0) {
            if (marca.getId() == 0) {
                return stockRepository.findAllByLocalAndProducto_Proveedor(pageable, local, proveedor);
            }
            if (proveedor.getId() == 0) {
                return stockRepository.findAllByLocalAndProducto_Marca(pageable, local, marca);
            }
            return stockRepository.findAllByLocalAndProducto_MarcaAndProducto_Proveedor(pageable, local, marca, proveedor);
        }

        if (marca.getId() == 0) {
            if (proveedor.getId() == 0) {
                return stockRepository.findAllByLocalAndProducto_Rubro(pageable, local, rubro);
            }
            return stockRepository.findAllByLocalAndProducto_RubroAndProducto_Proveedor(pageable, local, rubro, proveedor);
        }

        if (proveedor.getId() == 0) {
            return stockRepository.findAllByLocalAndProducto_RubroAndProducto_Marca(pageable, local, rubro, marca);
        }

        return stockRepository.findAllByLocalAndProducto_ProveedorAndProducto_RubroAndProducto_Marca(pageable, local, proveedor, rubro, marca);

    }
}
