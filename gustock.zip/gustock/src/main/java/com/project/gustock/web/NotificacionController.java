package com.project.gustock.web;

import com.project.gustock.model.Bandeja;
import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Usuario;
import com.project.gustock.service.BandejaService;
import com.project.gustock.service.NotificacionService;
import com.project.gustock.service.UsuarioService;
import org.aspectj.weaver.ast.Not;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class NotificacionController {

    @Autowired
    UsuarioService usuarioService;
    @Autowired
    NotificacionService notificacionService;
    @Autowired
    BandejaService bandejaService;

    @GetMapping("/notificaciones")
    public String verNotificaciones(Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Usuario usuario = usuarioService.findByUsername(authentication.getName());
        List<Bandeja> notificaciones = bandejaService.findAllByUsuarioAndLeidoIsNull(usuario);

        model.addAttribute("nuevaNotificacion", new Notificacion());
        model.addAttribute("notificaciones", notificaciones);
        return "notificaciones";
    }

    @GetMapping("/notificaciones/leidas")
    public String verNotificacionesLeidas(Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Usuario usuario = usuarioService.findByUsername(authentication.getName());

        List<Bandeja> notificaciones = bandejaService.findAllByUsuarioAndLeidoIsNotNull(usuario);

        model.addAttribute("estado", "leidas");
        model.addAttribute("notificaciones", notificaciones);
        return "notificaciones";
    }

    @GetMapping("/notificacion/{id}/marcar-leido")
    public String marcarLeido(@PathVariable("id") Long id, Model model) {
        Bandeja notificacionLeida = bandejaService.getById(id);
        notificacionLeida.setLeido(LocalDate.now());
        bandejaService.save(notificacionLeida);

        return "redirect:/notificaciones";
    }

    @GetMapping("/notificacion/{id}/eliminar")
    public String marcarLeido(@PathVariable("id") Long id) {
        Notificacion notificacion = notificacionService.getById(id);
        List<Bandeja> bandejas = bandejaService.findAllByNotificacion(notificacion);

        for (Bandeja bandeja: bandejas){
            bandejaService.delete(bandeja);
        }

        notificacionService.delete(notificacion);
        return "redirect:/notificaciones";
    }

    @PostMapping("/administrador/notificacion/registrar")
    public String registrarNotificacion(@ModelAttribute("nuevaNotificacion") Notificacion notificacion){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Usuario remitente = usuarioService.findByUsername(authentication.getName());
        notificacion.setRemitente(remitente.getUsername());
        notificacion.setFechaHora(LocalDateTime.now());
        Notificacion noti = notificacionService.save(notificacion);

        List<Usuario> usuarios = usuarioService.findAll();
        for (Usuario usuario : usuarios){
            Bandeja bandeja = new Bandeja();
            bandeja.setNotificacion(notificacion);
            bandeja.setUsuario(usuario);
            bandejaService.save(bandeja);
        }

        return "redirect:/notificaciones";
    }
}
