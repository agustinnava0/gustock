package com.project.gustock.service;

import com.project.gustock.model.Imagen;
import com.project.gustock.repository.ImagenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImagenServiceImpl implements ImagenService{

    @Autowired
    ImagenRepository imagenRepository;

    @Override
    public Imagen save(Imagen imagen) {return imagenRepository.save(imagen);}

    @Override
    public void delete(Imagen imagen) {imagenRepository.delete(imagen);}

}
