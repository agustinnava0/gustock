package com.project.gustock.web;

import com.project.gustock.model.Stock;
import com.project.gustock.service.StockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class StockController {

    @Autowired
    StockService stockService;

    @GetMapping("/local/{localId}/administrador/stock/{stockId}/eliminar")
    public String eliminarStock(@PathVariable("localId") Long localId, @PathVariable("stockId") Long stockId){
        Stock stock = stockService.getById(stockId);
        stockService.delete(stock);
        return "redirect:/local/" + localId;
    }

}
