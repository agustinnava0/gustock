package com.project.gustock.service;

import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Usuario;

import java.util.List;

public interface NotificacionService {

    Notificacion save(Notificacion notificacion);

    Notificacion findByAsunto(String asunto);

    Notificacion getById(Long id);

    void delete(Notificacion notificacion);
}
