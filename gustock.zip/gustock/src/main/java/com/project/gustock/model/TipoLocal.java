package com.project.gustock.model;

public enum TipoLocal {

    LOCAL, DEPOSITO
}
