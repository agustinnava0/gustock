package com.project.gustock.repository;

import com.project.gustock.model.Rol;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolRepository extends JpaRepository<Rol, Long>{

    Rol findRolByName(String name);
}
