package com.project.gustock.service;

import com.project.gustock.exceptions.ExceptionCodigoRepetido;
import com.project.gustock.exceptions.ExceptionProductoNoEncontrado;
import com.project.gustock.model.Marca;
import com.project.gustock.model.Producto;
import com.project.gustock.model.Proveedor;
import com.project.gustock.model.Rubro;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProductoService {

    Producto save(Producto producto) throws ExceptionCodigoRepetido;

    void delete(Producto producto);

    Producto getById(Long id);

    Page<Producto> findAll(Pageable pageable);

    Producto findByCodigo(String codigo) throws ExceptionProductoNoEncontrado;

    Producto findByCodigoOrBarcode_Codigo(String codigo, Long barcode) throws ExceptionProductoNoEncontrado;

    List<Producto> findAllByIds(List<Long> productIds);

    Page<Producto> findAllWithFilters(Proveedor proveedor, Rubro rubro, Marca marca, Pageable pageable);

    void incrementarPrecio(Integer porcentajeEfectivo, Integer porcentajeDebito, Integer porcentajeCredito, List<Producto> productosUpdate);

    void decrementarPrecio(Integer porcentajeEfectivo, Integer porcentajeDebito, Integer porcentajeCredito, List<Producto> productosUpdate);
}
