package com.project.gustock.repository;

import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {

    Notificacion findByAsunto(String asunto);

}
