package com.project.gustock.service;

import com.project.gustock.model.Barcode;

public interface BarcodeService {

    Barcode save (Barcode barcode);

    void delete (Barcode barcode);
}
