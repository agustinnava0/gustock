package com.project.gustock.repository;

import com.project.gustock.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface StockRepository extends JpaRepository<Stock, Long> {

    Stock findByLocalAndProducto(Local local, Producto producto);

    List<Stock> findAllByLocal(Local local);

    List<Stock> findAllByProducto(Producto producto);

    Page<Stock> findAllByLocal(Pageable pageable, Local local);

    Page<Stock> findAllByLocalAndProducto_Proveedor(Pageable pageable, Local local, Proveedor proveedor);

    Page<Stock> findAllByLocalAndProducto_Marca(Pageable pageable, Local local, Marca marca);

    Page<Stock> findAllByLocalAndProducto_Rubro(Pageable pageable, Local local, Rubro rubro);

    Page<Stock> findAllByLocalAndProducto_MarcaAndProducto_Proveedor(Pageable pageable, Local local, Marca marca, Proveedor proveedor);

    Page<Stock> findAllByLocalAndProducto_RubroAndProducto_Proveedor(Pageable pageable, Local local, Rubro rubro, Proveedor proveedor);

    Page<Stock> findAllByLocalAndProducto_RubroAndProducto_Marca(Pageable pageable, Local local, Rubro rubro, Marca marca);

    Page<Stock> findAllByLocalAndProducto_ProveedorAndProducto_RubroAndProducto_Marca(Pageable pageable, Local local, Proveedor proveedor, Rubro rubro, Marca marca);

}
