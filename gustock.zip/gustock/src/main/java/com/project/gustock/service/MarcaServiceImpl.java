package com.project.gustock.service;

import com.project.gustock.model.Marca;
import com.project.gustock.repository.MarcaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MarcaServiceImpl implements MarcaService{

    @Autowired
    MarcaRepository marcaRepository;

    @Override
    public void save(Marca marca){marcaRepository.save(marca);}

    @Override
    public void delete(Marca marca){marcaRepository.delete(marca);}

    @Override
    public List<Marca> findAll(){return marcaRepository.findAll();}

    @Override
    public Marca getById(Long id){return marcaRepository.getReferenceById(id);}
}
