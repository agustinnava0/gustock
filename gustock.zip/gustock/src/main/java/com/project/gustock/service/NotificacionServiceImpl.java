package com.project.gustock.service;

import com.project.gustock.model.Notificacion;
import com.project.gustock.model.Usuario;
import com.project.gustock.repository.NotificacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificacionServiceImpl implements NotificacionService{

    @Autowired
    NotificacionRepository notificacionRepository;

    @Override
    public Notificacion save(Notificacion notificacion) {return notificacionRepository.save(notificacion);}

    @Override
    public Notificacion findByAsunto(String asunto) {return notificacionRepository.findByAsunto(asunto);}

    @Override
    public Notificacion getById(Long id) {return notificacionRepository.getReferenceById(id);}

    @Override
    public void delete(Notificacion notificacion) {notificacionRepository.delete(notificacion);}

}
