package com.project.gustock.web;

import com.project.gustock.exceptions.ExceptionProductoNoEncontrado;
import com.project.gustock.model.*;
import com.project.gustock.service.LocalService;
import com.project.gustock.service.ProductoService;
import com.project.gustock.service.StockService;
import com.project.gustock.service.VentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class VentaController {

    @Autowired
    private VentaService ventaService;

    @Autowired
    private ProductoService productoService;

    @Autowired
    private LocalService localService;

    @Autowired
    private StockService stockService;

    @GetMapping("/local/{id}/venta/registrar")
    public String irRegistrarVenta(@PathVariable("id") Long localId, Model model){
        Local local = localService.getById(localId);
        List<String> precios = Arrays.asList(TipoPrecio.CONTADO.toString(), TipoPrecio.DEBITO.toString(), TipoPrecio.CREDITO.toString());

        model.addAttribute("local", local);
        model.addAttribute("precios", precios);
        model.addAttribute("fecha", LocalDate.now());
        return "registrar-venta";
    }

    @PostMapping("/local/{id}/venta/registrar")
    public String registrarVenta(@PathVariable("id") Long localId){
        Local local = localService.getById(localId);

        return "registrar-venta";
    }

    @GetMapping("/venta/producto/{codigo}")
    @ResponseBody
    public Map<String, Object> getProductByCode(@PathVariable("codigo") String codigo, @RequestParam("tipoPrecio") TipoPrecio tipo) throws ExceptionProductoNoEncontrado {
        Map<String, Object> response = new HashMap<>();

        Producto producto;
        Long barcode = Long.valueOf(0);

        if (codigo.length() == 13 && codigo.matches("[0-9]+")){
            barcode = Long.valueOf(codigo);
        }

        producto = productoService.findByCodigoOrBarcode_Codigo(codigo, barcode);

        if (producto != null) {
            response.put("codigo", producto.getCodigo());
            response.put("descripcion", producto.getDescripcion());
            switch (tipo) {
                case DEBITO:
                    response.put("tipo", TipoPrecio.DEBITO);
                    response.put("precio", producto.getPrecioDebito());
                    break;
                case CONTADO:
                    response.put("tipo", TipoPrecio.CONTADO);
                    response.put("precio", producto.getPrecioEfectivo());
                    break;
                case CREDITO:
                    response.put("tipo", TipoPrecio.CREDITO);
                    response.put("precio", producto.getPrecioCredito());
                    break;
                default:
                    break;
            }
        }

        return response;
    }

}
