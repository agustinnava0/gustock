package com.project.gustock.service;

import com.project.gustock.model.Barcode;
import com.project.gustock.repository.BarcodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BarcodeServiceImpl implements BarcodeService{

    @Autowired
    BarcodeRepository barcodeRepository;

    @Override
    public Barcode save(Barcode barcode) {return barcodeRepository.save(barcode);}

    @Override
    public void delete(Barcode barcode) {barcodeRepository.delete(barcode);}

}
