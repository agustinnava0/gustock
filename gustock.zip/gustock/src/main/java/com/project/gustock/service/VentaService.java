package com.project.gustock.service;

import com.project.gustock.model.Venta;

public interface VentaService {

    void save (Venta venta);
}
