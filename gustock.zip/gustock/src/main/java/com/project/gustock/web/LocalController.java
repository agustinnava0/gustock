package com.project.gustock.web;

import com.project.gustock.model.*;
import com.project.gustock.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Controller
public class LocalController {

    @Autowired
    private LocalService localService;

    @Autowired
    private RubroService rubroService;

    @Autowired
    private MarcaService marcaService;

    @Autowired
    private ProveedorService proveedorService;

    @Autowired
    private StockService stockService;

    @Autowired
    private FileService fileService;

    @GetMapping({"/local/{id}", "/administrador/deposito/{id}"})
    public String verLocal(@RequestParam Map<String, Object> params, @PathVariable("id") Long id, Model model) {
        Local local = localService.getById(id);
        Producto nuevoProducto = new Producto();

        // Selects
        List<Marca> marcas = marcaService.findAll();
        List<Rubro> rubros = rubroService.findAll();
        List<Proveedor> proveedores = proveedorService.findAll();
        List<String> cantidadDeRegitrosPorPaginas = Arrays.asList("10", "20", "30", "40", "50", "Todos");
        // Fin selects

        // Paginacion
        int recordsQuantity;
        if (params.get("recordsQuantity") != null && params.get("recordsQuantity").toString().equals("Todos")) {
            recordsQuantity = Integer.MAX_VALUE;
        } else {
            recordsQuantity = params.get("recordsQuantity") != null ? Integer.parseInt(params.get("recordsQuantity").toString()) : Integer.parseInt(cantidadDeRegitrosPorPaginas.get(0));
        }

        int page = params.get("page") != null ? (Integer.parseInt(params.get("page").toString()) - 1) : 0;

        PageRequest pageRequest = PageRequest.of(page, recordsQuantity, Sort.by(Sort.Direction.DESC, "id"));
        // Fin Paginacion

        if (params.get("orderByStock") != null) {
            String stock = params.get("orderByStock").toString();
            switch (stock) {
                case "Desc":
                    pageRequest = pageRequest.withSort(Sort.by(Sort.Direction.DESC, "cantidad"));
                    break;
                case "Asc":
                    pageRequest = pageRequest.withSort(Sort.by(Sort.Direction.ASC, "cantidad"));
                    break;
                default:
                   break;
            }
        }

        // Filtrado
        Proveedor proveedor = params.get("proveedor") != null ? proveedorService.getById(Long.valueOf(params.get("proveedor").toString())) : null;
        Rubro rubro = params.get("rubro") != null ? rubroService.getById(Long.valueOf(params.get("rubro").toString())) : null;
        Marca marca = params.get("marca") != null ? marcaService.getById(Long.valueOf(params.get("marca").toString())) : null;

        Page<Stock> stockPage;
        if (proveedor == null && rubro == null && marca == null) {
            stockPage = stockService.findAllByLocal(pageRequest, local);
        } else {
            stockPage = stockService.findAllByLocalWithFilters(pageRequest, local, proveedor, rubro, marca);
        }
        // Fin Filtrado

        int totalPage = stockPage.getTotalPages();
        if (totalPage > 0) {
            List<Integer> pages = IntStream.rangeClosed(1, totalPage).boxed().collect(Collectors.toList());
            model.addAttribute("pages", pages);
        }
        List<Stock> listaProductos = stockPage.getContent();

        model.addAttribute("current", page + 1);
        model.addAttribute("next", page + 2);
        model.addAttribute("prev", page);
        model.addAttribute("last", totalPage);
        model.addAttribute("cantidadDeRegitrosPorPaginas", cantidadDeRegitrosPorPaginas);
        model.addAttribute("recordsQuantity", (recordsQuantity == Integer.MAX_VALUE ? "Todos" : recordsQuantity));

        model.addAttribute("local", local);
        model.addAttribute("listaProductos", listaProductos);
        model.addAttribute("nuevoProducto", nuevoProducto);

        model.addAttribute("marcas", marcas);
        model.addAttribute("brand", (params.get("marca") != null ? Long.valueOf(params.get("marca").toString()) : 0));

        model.addAttribute("rubros", rubros);
        model.addAttribute("category", (params.get("rubro") != null ? Long.valueOf(params.get("rubro").toString()) : 0));

        model.addAttribute("proveedores", proveedores);
        model.addAttribute("provider", (params.get("proveedor") != null ? Long.valueOf(params.get("proveedor").toString()) : 0));

        model.addAttribute("orderByStock", (params.get("orderByStock") != null ? params.get("orderByStock").toString() : null));

        return "local";
    }

    @GetMapping(value = "/administrador/productos/exportar")
    public ResponseEntity exportToExcel(@RequestParam Map<String, Object> params) {
        Local local = localService.getById(Long.valueOf((params.get("local").toString())));

        // Paginacion
        int recordsQuantity;
        if (params.get("recordsQuantity") != null && params.get("recordsQuantity").toString().equals("Todos")) {
            recordsQuantity = Integer.MAX_VALUE;
        } else {
            recordsQuantity = params.get("recordsQuantity") != null ? Integer.parseInt(params.get("recordsQuantity").toString()) : 10;
        }

        PageRequest pageRequest = PageRequest.of(0, recordsQuantity, Sort.by(Sort.Direction.DESC, "id"));
        // Fin Paginacion

        if (params.get("orderByStock") != null) {
            String stock = params.get("orderByStock").toString();
            switch (stock) {
                case "Desc":
                    pageRequest = pageRequest.withSort(Sort.by(Sort.Direction.DESC, "cantidad"));
                    break;
                case "Asc":
                    pageRequest = pageRequest.withSort(Sort.by(Sort.Direction.ASC, "cantidad"));
                    break;
                default:
                    break;
            }
        }

        // Filtrado
        Proveedor proveedor = params.get("proveedor") != null ? proveedorService.getById(Long.valueOf(params.get("proveedor").toString())) : null;
        Rubro rubro = params.get("rubro") != null ? rubroService.getById(Long.valueOf(params.get("rubro").toString())) : null;
        Marca marca = params.get("marca") != null ? marcaService.getById(Long.valueOf(params.get("marca").toString())) : null;

        Page<Stock> stockPage;
        if (proveedor == null && rubro == null && marca == null) {
            stockPage = stockService.findAllByLocal(pageRequest, local);
        } else {
            stockPage = stockService.findAllByLocalWithFilters(pageRequest, local, proveedor, rubro, marca);
        }
        // Fin Filtrado

        List<Stock> listaProductos = stockPage.getContent();

        // Export to Excel
        byte[] excelBytes;
        try {
            excelBytes = fileService.exportToExcel(listaProductos, local);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "stock.xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excelBytes);
    }

}
