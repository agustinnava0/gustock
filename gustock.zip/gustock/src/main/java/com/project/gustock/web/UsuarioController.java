package com.project.gustock.web;

import com.project.gustock.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class UsuarioController {

    @Autowired
    UsuarioService usuarioService;

}
