package com.project.gustock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GustockApplicationTests {

    @Test
    void contextLoads() {
    }

}
